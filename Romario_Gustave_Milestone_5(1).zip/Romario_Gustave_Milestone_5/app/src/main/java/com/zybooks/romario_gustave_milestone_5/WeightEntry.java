package com.zybooks.romario_gustave_milestone_5;
public class WeightEntry {
    private int id;
    private String date;
    private double weight;

    public WeightEntry() {
        // Default constructor required for calls to DataSnapshot.getValue(WeightEntry.class)
    }

    public WeightEntry(String date, double weight) {
        this.date = date;
        this.weight = weight;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }
}
