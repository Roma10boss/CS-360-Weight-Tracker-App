package com.zybooks.romario_gustave_milestone_5;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class GridViewAdapter extends BaseAdapter {
    private Context context;
    private List<WeightEntry> weightEntryList;
    DatabaseHelper databaseHelper;

    public GridViewAdapter(Context context, List<WeightEntry> weightEntries) {
        this.context = context;
        this.weightEntryList = weightEntries;
    }

    @Override
    public int getCount() {
        return weightEntryList.size();
    }

    @Override
    public Object getItem(int position) {
        return weightEntryList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_layout, parent, false);
            holder = new ViewHolder();
            holder.tvDate = convertView.findViewById(R.id.tvDate);
            holder.tvWeight = convertView.findViewById(R.id.tvWeight);
            holder.updateBtn = convertView.findViewById(R.id.update_btn);
            holder.deleteBtn = convertView.findViewById(R.id.delete_btn);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        databaseHelper = new DatabaseHelper(context);
        WeightEntry entry = weightEntryList.get(position);
        holder.tvDate.setText(entry.getDate());
        holder.tvWeight.setText(String.format("%s lbs", entry.getWeight()));
        holder.updateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context.getApplicationContext(),UpdateDataActivity.class);
                intent.putExtra("id",entry.getId());
                context.startActivity(intent);
            }
        });
        holder.deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                databaseHelper.deleteWeightEntry(weightEntryList.get(position).getId());
                weightEntryList.remove(position);
                notifyDataSetChanged();
                Toast.makeText(context,"Item Deleted Successfully",Toast.LENGTH_SHORT).show();
            }
        });
        return convertView;
    }

    static class ViewHolder {
        TextView tvDate;
        TextView tvWeight;
        Button updateBtn;
        Button deleteBtn;
    }
}
