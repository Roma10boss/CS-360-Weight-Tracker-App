package com.zybooks.romario_gustave_milestone_5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddWeightActivity extends AppCompatActivity {
    EditText dateEditText;
    EditText weightEditText;
    Button addDataButton;
    DatabaseHelper databaseHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight);
        databaseHelper = new DatabaseHelper(this);
        dateEditText = findViewById(R.id.dateEditText);
        weightEditText = findViewById(R.id.weightEditText);
        addDataButton = findViewById(R.id.addDataButton);
        addDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!weightEditText.getText().toString().isEmpty()&&!dateEditText.getText().toString().isEmpty()) {
                    WeightEntry weightEntry = new WeightEntry();
                    weightEntry.setWeight(Double.valueOf(weightEditText.getText().toString()));
                    weightEntry.setDate(dateEditText.getText().toString());
                    databaseHelper.addWeightEntry(weightEntry);
                    Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                    startActivity(intent);
                    Toast.makeText(AddWeightActivity.this,"Data is Added To Database",Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(AddWeightActivity.this,"Empty Fields",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}