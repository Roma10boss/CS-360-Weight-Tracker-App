package com.zybooks.romario_gustave_milestone_5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UpdateDataActivity extends AppCompatActivity {
    EditText dateEditText;
    EditText weightEditText;
    Button addUpdateButton;
    DatabaseHelper databaseHelper;
    int id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_data);
        Intent intent = getIntent();
        id = intent.getIntExtra("id",0);
        databaseHelper = new DatabaseHelper(this);
        dateEditText = findViewById(R.id.dateEditText);
        weightEditText = findViewById(R.id.weightEditText);
        addUpdateButton = findViewById(R.id.updateDataButton);

        WeightEntry entry = databaseHelper.getWeightEntryById(id);
        dateEditText.setText(entry.getDate());
        weightEditText.setText(String.valueOf(entry.getWeight()));

        addUpdateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!weightEditText.getText().toString().isEmpty()&&!dateEditText.getText().toString().isEmpty()) {
                    WeightEntry weightEntry = new WeightEntry();
                    weightEntry.setWeight(Double.parseDouble(weightEditText.getText().toString()));
                    weightEntry.setDate(dateEditText.getText().toString());
                    weightEntry.setId(id);
                    databaseHelper.updateWeightEntry(weightEntry);
                    Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                    startActivity(intent);
                    Toast.makeText(UpdateDataActivity.this,"Data is Updated To Database",Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(UpdateDataActivity.this,"Empty Fields",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}