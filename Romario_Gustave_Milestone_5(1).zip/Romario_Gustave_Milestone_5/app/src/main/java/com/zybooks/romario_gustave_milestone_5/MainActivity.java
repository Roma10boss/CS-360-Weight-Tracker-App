package com.zybooks.romario_gustave_milestone_5;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    Button addDataButton;
    GridView gridView;
    DatabaseHelper databaseHelper;
    List<WeightEntry> weightEntries;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        databaseHelper = new DatabaseHelper(this);
        addDataButton = findViewById(R.id.addDataButton);
        gridView = findViewById(R.id.dataGridView);
        addDataButton = findViewById(R.id.addDataButton);
        addDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),AddWeightActivity.class);
                startActivity(intent);
            }
        });
        // Fetch the data from database
        weightEntries = databaseHelper.getAllWeightEntries();

        // Set up the adapter
        GridViewAdapter adapter = new GridViewAdapter(this, weightEntries);
        gridView.setAdapter(adapter);
        sentMessage();
    }
    void sentMessage(){
        int weight = 0;
        if(weightEntries.size()>0) {
            for(int i=0;i<weightEntries.size();i++)
            {
                weight = (int) (weight+weightEntries.get(i).getWeight());
            }
            if(weight>=20) {
                if (ContextCompat.checkSelfPermission(MainActivity.this,
                        android.Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage("(650) 555-1212", null, "Weight Goal Achieved", null, null);
                }
            }
        }
    }
}
