package com.zybooks.romario_gustave_milestone_5;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    // Define your table and column names
    public static final String TABLE_NAME = "weight_entries";
    private static final String DATABASE_NAME = "weight_tracker.db";
    private static final int DATABASE_VERSION = 1;
    protected static final String COLUMN_ID = "entry_id";


    private static final String COLUMN_DATE = "entry_date";
    private static final String COLUMN_WEIGHT = "weight";
    public static final String COLUMN_ITEM_NAME = "item_name"; // Made public

    // SQL statement to create the table
    private static final String SQL_CREATE_TABLE =
            "CREATE TABLE " + TABLE_NAME + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_DATE + " TEXT, " +
                    COLUMN_WEIGHT + " REAL, " +
                    COLUMN_ITEM_NAME + " TEXT)";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create the database table
        db.execSQL(SQL_CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Handle database upgrade if needed
    }

    // Method to add a new weight entry
    public void addWeightEntry(WeightEntry weightEntry) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_DATE, weightEntry.getDate());
        values.put(COLUMN_WEIGHT, weightEntry.getWeight());
        db.insert(TABLE_NAME, null, values);
        db.close();
    }

    // Method to get all weight entries
    public List<WeightEntry> getAllWeightEntries() {
        List<WeightEntry> weightEntries = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_NAME;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                WeightEntry weightEntry = new WeightEntry();
                weightEntry.setId(cursor.getInt(cursor.getColumnIndex(COLUMN_ID)));
                weightEntry.setDate(cursor.getString(cursor.getColumnIndex(COLUMN_DATE)));
                weightEntry.setWeight(cursor.getDouble(cursor.getColumnIndex(COLUMN_WEIGHT)));
                weightEntries.add(weightEntry);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return weightEntries;
    }

    // Method to delete a weight entry
    public void deleteWeightEntry(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME, COLUMN_ID + " = ?",
                new String[]{String.valueOf(id)});
        db.close();
    }
    public int updateWeightEntry(WeightEntry weightEntry) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_DATE, weightEntry.getDate());
        values.put(COLUMN_WEIGHT, weightEntry.getWeight());
        // Updating row
        int updateStatus = db.update(TABLE_NAME, values, COLUMN_ID + " = ?",
                new String[]{String.valueOf(weightEntry.getId())});
        db.close();
        return updateStatus; // This will return the number of rows affected
    }
    public WeightEntry getWeightEntryById(int id) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_NAME, new String[] { COLUMN_ID,
                        COLUMN_DATE, COLUMN_WEIGHT, COLUMN_ITEM_NAME }, COLUMN_ID + "=?",
                new String[] { String.valueOf(id) }, null, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();

        WeightEntry weightEntry = new WeightEntry();
        // Check if the cursor has at least one row
        if (cursor.getCount() > 0) {
            weightEntry.setId(cursor.getInt(cursor.getColumnIndex(COLUMN_ID)));
            weightEntry.setDate(cursor.getString(cursor.getColumnIndex(COLUMN_DATE)));
            weightEntry.setWeight(cursor.getDouble(cursor.getColumnIndex(COLUMN_WEIGHT)));
            // Optionally, retrieve the item name if you need it
            // weightEntry.setItemName(cursor.getString(cursor.getColumnIndex(COLUMN_ITEM_NAME)));
        }
        cursor.close();
        db.close();
        return weightEntry;
    }
    public static String getTableName() {
        return TABLE_NAME;
    }
    public static String getColumnId() {
        return COLUMN_ID;
    }
}
